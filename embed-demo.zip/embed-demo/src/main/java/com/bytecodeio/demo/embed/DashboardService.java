package com.bytecodeio.demo.embed;

public interface DashboardService {
	public String getDashboardEmbedUrl(String dashboardId)throws Exception;
}
